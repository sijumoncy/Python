#Normal Test code Writing
"""
from area import circle_area

#creating test values
values = [2, 0, -3, 2+5j, True, "radius"] # j is sqrt of -1
message = "Area of circle with radius r =  {} is {}."

for v in values:
    A = circle_area(v)
    print(message.format(v,A))
    

#Run this test code to check errors in the codes    

#error will come at string value
"""

#proper test code writing 

import unittest 
from area import circle_area
from math import pi

class TestCircleAread(unittest.TestCase):
    def test_area(self):
        self.assertAlmostEqual(circle_area(1), pi)
        self.assertAlmostEqual(circle_area(0), 0)
        self.assertAlmostEqual(circle_area(2.1), pi*2.1**2)
        
