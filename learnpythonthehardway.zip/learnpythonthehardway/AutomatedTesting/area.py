#simple program to find the area of circle 
from math import pi

def circle_area(r):
    return pi*(r**2)