from sys  import argv

script, name = argv
prompt = '> '

print("hi %s i am %s"%(script,name))

print("do you like me ?")
like = input(prompt)
