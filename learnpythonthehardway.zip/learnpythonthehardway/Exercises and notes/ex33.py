#converting while loop to print 1-6 to a function that can call with a variable

def createlist(limit,increament):
    i = 0
    list = []
    while  i <= limit:
         list.append(i)
         i+=increament
    return list

print("Enter the Maximum Number and the INCREMENT needed")
limit = int(input('> '))
inc = int(input('> '))

list_get = createlist(limit,inc)

for i in list_get:
    print(i)
