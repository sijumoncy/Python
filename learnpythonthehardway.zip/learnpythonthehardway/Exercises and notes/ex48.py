#scanning input and finding the  token and words

#create Lexicon 


lexicon = {
    'Direction':['north', 'south', 'east', 'west', 'down', 'up', 'left', 'right', 'back'],
    'Verb':['go', 'stop', 'kill', 'eat'],
    'StopWord':['the', 'in', 'of', 'from', 'at', 'it'],
    'Noun' : ['door', 'Bear', 'prince', 'cabinet'],
    'Numbers' : ['0','1','2','3','4','5','6','7','8','9']
}

print("Enter a Sentance")
text = input('>')
text_lower = text.lower()
word_list = text_lower.split()

output = []
found = False
token = 'not-found'

#print(word_list) 

for w in word_list:
    for l in lexicon:
        if w in lexicon[l]:
            found = True
            token = l
    set_temp=(token,w) 
    output.append(set_temp)       
    token = 'not-found'        


print(text)
for i in output:
    print(i)