#function to calculate a formula 

#formula c= (a+b)*(a-b)


def multiply(a,b):
    return a * b 

def add(a,b):
    return a + b

def sub(a,b):
    return a - b

a = 10
b = 5

print(multiply(add(a,b),sub(a,b)))       
