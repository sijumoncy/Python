#Files operations exercises

#create file 

open("create.txt",'x')

#Write contents

with open("create.txt",'w') as f:
    f.write("This is the content written using write function\n")

#read content
with open("create.txt",'r') as f:
   content = f.read()
#truncate contents
   #f.truncate()
   print(content)

# append another line 

with open("create.txt",'a') as f:
    f.write("second line added using append mode")

#read lines
with open("create.txt",'r') as f:
   content_line = f.readlines()
   print(content_line)    

#copying the content to another file

with open("create.txt",'r') as f:
   content = f.read()

   with open("filecopy",'w') as file:
      file.write(content)


   


        