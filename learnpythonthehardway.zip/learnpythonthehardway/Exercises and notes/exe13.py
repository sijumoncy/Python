from sys import argv

a, b, c, d = argv

print(a)
print(b)
print(c)
print(d)
