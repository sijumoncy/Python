#format characters

name = "python"
type = "langauage"
version = 3

print("Hi, I am %s and I am a programing %s .Current version is %d" %(name,type,version))