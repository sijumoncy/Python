# -*- coding: utf-8 -*- 
#Printing statements

print("printing sample text to console or terminal")
