from nose.tools import *
import NAME

def setup():
    print("Setup")

def teardown():
    print("Tear Down")

def test_basic():
    print("I Ran")        