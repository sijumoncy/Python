from main.forms import LoginForm
from django.contrib.auth.forms import AuthenticationForm
from django.urls import path
from django.utils.translation import templatize
from main import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('',views.HomeView.as_view(),name="home"),
    path('buy/<int:id>', views.BuyView.as_view(),name="buy"),
    path('product_detail/<slug:cat>', views.product_detailView.as_view(),name="product_detail"),
    path('signup/',views.SignupView.as_view(),name="signup"),
    path('logout/',auth_views.LogoutView.as_view(next_page='login'),name = 'logout'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name = 'main/login.html', authentication_form = LoginForm), name="login"),
    path('profile/',  views.ProfileView.as_view(),name="profile"),
    path('address/',views.address,name="address"),
    path('addtocart/',views.addtocart,name="addtocart"),
    path('showcart/',views.showcart,name="showcart"),
    path('pluscart/',views.plus_cart,name="pluscart"),
    path('minuscart/',views.minus_cart,name="minuscart"),
    path('removecart/',views.remove_cart,name="removecart"),
    path('checkout/',views.checkout,name="checkout"),

    path('orders/',views.orders,name="orders"),
    path('changepass/',views.changepass,name="changepass"),
    path('aboutus/',views.aboutus,name="aboutus"),
    path('contactus/',views.contactus,name="contactus"),
    path('buynow/',views.buynow,name="buynow"),
]+ static(settings.MEDIA_URL,document_root = settings.MEDIA_ROOT)
