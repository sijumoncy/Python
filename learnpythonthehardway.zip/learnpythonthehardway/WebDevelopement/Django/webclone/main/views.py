from django import forms
from django.http.response import JsonResponse
from django.shortcuts import redirect, render
from django.views import View
from .models import Product,Customer,Cart,OrderPlaced
from django.http import HttpResponse
from .forms import CustomerRegistrationForm, ProfileForm
from django.contrib import messages
from django.db.models import Q

class HomeView(View):
    def get(self,request):
        electronics = Product.objects.filter(category = 'E')
        Gadjets = Product.objects.filter(category = 'G')
        Health = Product.objects.filter(category = 'H')
        Computer = Product.objects.filter(category = 'C')
        context = {
            'electronics':electronics,
            'Gadjets':Gadjets,
            'Health':Health,
            'Computer':Computer,
        }
        return render(request,"main/home.html",context)

class BuyView(View):
    def get(self,request,id):

        product = Product.objects.get(pk=id)
        context = {
            'product':product,
        }
        return render(request,"main/buy.html",context)      

class product_detailView(View):
    def get(self,request,cat):

        product = Product.objects.filter(category = cat)
        context = {
            'product':product,
            'cat':cat
        }
        return render(request,"main/product_detail.html",context)    


class SignupView(View):
    def get(self,request):
        form = CustomerRegistrationForm()
        return render(request, "main/signup.html", {'form':form})

    def post(self,request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Successfully Registered')
            form.save()
        return render(request, "main/signup.html", {'form':form})    

class ProfileView(View):
    def get(self,request):
        form = ProfileForm()
        return render(request,"main/profile.html",{'form':form, 'active':'btn btn-secondary'})

    def post(self,request):
        form = ProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']
            reg = Customer(user=usr, name=name, locality=locality, city=city, state=state, zipcode=zipcode )
            reg.save()
            messages.success(request, 'Address Successfully Saved')
        return render(request,"main/profile.html",{'form':form, 'active':'btn btn-secondary'})
        

def address(request):
    address = Customer.objects.filter(user=request.user)
    return render(request,"main/address.html",{'active':'btn btn-secondary','address':address})

def addtocart(request):
    if request.user.is_authenticated:
        usr = request.user
        product_id = request.GET.get("product_id")
        product = Product.objects.get(id=product_id)
        Cart(user=usr, product=product).save()
        return redirect('/showcart')  
    else:
        return redirect("/signup")     

def showcart(request):
    if request.user.is_authenticated:
        usr = request.user
        cart = Cart.objects.filter(user=usr)  
        amount = 0
        shiping_amount = 50.0
        total_amout= 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == usr] 
        if cart_product:
            for p in cart_product:
                temp_amount = (p.quantity) * (p.product.selling_price - p.product.discount_price) 
                amount+=temp_amount
            total_amout = amount + shiping_amount    
            return render(request,"main/cart.html", {'cart':cart, 'total':total_amout, 'shiping':shiping_amount, 'amount':amount})  
        else:
            return render(request,"main/empty_cart.html")
    else:
        return redirect("main/signup.html")        


def plus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product = prod_id) & Q(user = request.user))
        c.quantity+=1
        c.save()
        amount = 0
        shiping_amount = 50.0
        total_amout= 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
                temp_amount = (p.quantity) * (p.product.selling_price - p.product.discount_price) 
                amount+=temp_amount
                total_amout = amount + shiping_amount 
        data = {
        'quantity': c.quantity,
        'amount':amount,
        'total':total_amout
        }         
        return JsonResponse(data)

def minus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product = prod_id) & Q(user = request.user))
        c.quantity-=1
        c.save()
        amount = 0
        shiping_amount = 50.0
        total_amout= 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
                temp_amount = (p.quantity) * (p.product.selling_price - p.product.discount_price) 
                amount+=temp_amount
                total_amout = amount + shiping_amount 
        data = {
        'quantity': c.quantity,
        'amount':amount,
        'total':total_amout
        }         
        return JsonResponse(data)

def remove_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product = prod_id) & Q(user = request.user))
        c.delete()
        amount = 0
        shiping_amount = 50.0
        total_amout= 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
                temp_amount = (p.quantity) * (p.product.selling_price - p.product.discount_price) 
                amount+=temp_amount
                total_amout = amount + shiping_amount 
        data = {
        'amount':amount,
        'total':total_amout
        }         
        return JsonResponse(data)

def checkout(request):
    usr = request.user
    address = Customer.objects.filter(user = usr)
    cart_item = Cart.objects.filter(user = usr)
    amount = 0
    shiping = 50.0
    total = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user == request.user]
    for p in cart_product:
            temp_amount = (p.quantity) * (p.product.selling_price - p.product.discount_price) 
            amount+=temp_amount
    total = amount + shiping 
    return render(request,"main/checkout.html",{'address':address,'total':total, 'items': cart_item})      

def aboutus(request):
    return render(request,"main/aboutus.html")

def contactus(request):
    return render(request,"main/contactus.html")




def orders(request):
    return render(request,"main/orders.html")


def changepass(request):
    return render(request,"main/changepass.html")




def buynow(request):
    return render(request,"main/checkout.html")                      