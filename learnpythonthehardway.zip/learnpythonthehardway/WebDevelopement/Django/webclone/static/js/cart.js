$('.plus-cart').click(function(){
    var id = $(this).attr('pid').toString();
    var elm = this.parentNode.children[2]
    console.log(id);

    $.ajax({
        type: "GET",
        url: "/pluscart",
        data: {
            prod_id:id
        },
        success: function (data) {
            //console.log(data)
            elm.innerText = data.quantity;
            document.getElementById('amount_span').innerText = data.amount;
            document.getElementById('total_span').innerText = data.total;

        }
    });
})

$('.minus-cart').click(function(){
    var id = $(this).attr('pid').toString();
    var elm = this.parentNode.children[2]
    console.log(id);

    $.ajax({
        type: "GET",
        url: "/minuscart",
        data: {
            prod_id:id
        },
        success: function (data) {
            //console.log(data)
            elm.innerText = data.quantity;
            document.getElementById('amount_span').innerText = data.amount;
            document.getElementById('total_span').innerText = data.total;

        }
    });
})


$('.remove-btn').click(function(){
    var id = $(this).attr('pid').toString();
    console.log(id);

    $.ajax({
        type: "GET",
        url: "/removecart",
        data: {
            prod_id:id
        },
        success: function (data) {
            //console.log(data)
            document.getElementById('amount_span').innerText = data.amount;
            document.getElementById('total_span').innerText = data.total;
            document.getElementById('product-row').remove()
            //elm.parentNode.parentNode.parentNode.remove();

        }
    });
})